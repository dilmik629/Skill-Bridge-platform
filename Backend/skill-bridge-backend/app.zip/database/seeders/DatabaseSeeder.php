<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            AdminSeeder::class,    // admin@skillbridge.com / Admin@1234
            CategorySeeder::class, // Web Dev, UI/UX, Backend, AI/ML, Mobile
        ]);
    }
}